import { BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Enroll from './Components/Enroll';
function App() {

  return ( 
    <Router>
      <Routes>
        <Route path='/' element={<Enroll/>}></Route>
      </Routes>
    </Router>
   );
}

export default App;