import { useEffect, useState } from "react";
function Enroll() {
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [website, setWebsite] = useState('')
    const [file, setFile] = useState('')
    const [message, setMessage] = useState('')
    const [message2, setMessage2] = useState('')
    const [students, setStudents] = useState([])

    function handleform(e) {
        e.preventDefault()
        let data = new FormData()
        data.append('name', name)
        data.append('email', email)
        data.append('website', website)
        data.append('file', file)
        fetch('/', {
            method: 'POST',
            body: data
        }).then((result) => { return result.json() }).then((data) => {
            // console.log(data)
            if (data.status === 201) {
                setMessage(data.message)
            }
            else {
                setMessage(data.message)
            }
        })
    }

    useEffect(() => {
        fetch('/enrollrecord').then((result) => { return result.json() }).then((data) => {
            console.log(data)
            if (data.status === 200) {
                setStudents(data.apiData)
            }
            else {
                setMessage2(data.message2)
            }
        })
    }, [])
    return (
        <section>
            <div className="container">
                <div className="row">
                    <div className="col-md-4">
                        <form onSubmit={(e) => { handleform(e) }} id='form'>
                            <p>{message}</p>
                            <label>Name</label>
                            <input type='text' className="form-control"
                                value={name}
                                onChange={(e) => { setName(e.target.value) }}
                            ></input>
                            <label>E-mail</label>
                            <input type='email' className="form-control"
                                value={email}
                                onChange={(e) => { setEmail(e.target.value) }}
                            ></input>
                            <label>Website</label>
                            <input type="text" className="form-control"
                                value={website}
                                onChange={(e) => { setWebsite(e.target.value) }}
                            ></input>
                            <label>Image</label>
                            <input type='file' className="form-control"
                                onChange={(e) => { setFile(e.target.files[0]) }}
                            ></input>
                            <button type="submit" className="btn btn-success form-control mt-2">Enroll</button>
                        </form>
                    </div>
                    
                            <div className="col-md-8">
                                <p>{message2}</p>
                                {students.length !== 0 ?
                        <>
                                <table className="table table-hover mt-5">
                                    <thead>
                                        <tr>
                                            <th>S.no</th>
                                            <th>Name</th>
                                            <th>E-mail</th>
                                            <th>Website</th>
                                            <th>Image</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {students.map((result, key) => (
                                            <tr key={result._id}>
                                                <td>{key + 1}</td>
                                                <td>{result.Name}</td>
                                                <td>{result.Email}</td>
                                                <td>{result.Website}</td>
                                                <td><img style={{ width: "150px" }} src={`/upload/${result.Image}`} /></td>
                                            </tr>
                                        ))}

                                    </tbody>
                                </table>
                                </>
                                :
                                    <h2 style={{textAlign:'center'}}>No Record Found</h2>
                                        }
                            </div>
                                        

            </div>
            </div>
        </section>
    );
}

export default Enroll;