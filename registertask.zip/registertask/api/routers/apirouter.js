const router=require('express').Router()
const enrollc=require("../controllers/enrollcontroller")
const multer=require('multer')
const enroll = require('../models/enroll')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})

router.post('/',upload.single('file'),enrollc.Enroll)
router.get('/enrollrecord',enrollc.enrollrecord)



module.exports=router