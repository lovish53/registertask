const Enroll = require('../models/enroll')


exports.Enroll = (req, res) => {
    const { name, email, website } = req.body
    const filename = req.file.filename
    try {
        const record = new Enroll({ Name: name, Email: email, Website: website, Image: filename })
        record.save()
        res.json({
            status: 201,
            message: 'Record has been succefully inserted',
        })
    }
    catch (error) {
        res.json({
            status: 400,
            message: error.message
        })
    }
}

exports.enrollrecord = async (req, res) => {
    try {
        const record = await Enroll.find()
        res.json({
            status: 200,
            apiData:record

        })
    } catch (error) {
        res.json({
            status:500,
            message:error.message
        })

    }
}


