const express=require('express') //function
const app=express() // module
const apirouter=require('./routers/apirouter')
app.use(express.json())
require('dotenv').config()
const mongoose=require('mongoose')
mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`)



app.use(apirouter)
app.use(express.static('public'))
app.listen(process.env.PORT)