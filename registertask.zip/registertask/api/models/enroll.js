const mongoose=require('mongoose')

const EnrollSchema=mongoose.Schema({
    Name:String,
    Email:String,
    Website:String,
    Image:String
})

module.exports=mongoose.model('enroll',EnrollSchema)